poetry install

poetry run python extract.py
